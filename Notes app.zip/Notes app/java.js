const title = document.getElementById("title");
const content = document.getElementById("content");
const tags = document.getElementById("tags");
const addBtn = document.getElementById("addBtn");
const notesContainer = document.getElementById("notesContainer");
const search = document.getElementById("search");

let notes = JSON.parse(localStorage.getItem("notes")) || [];

function saveNotes(){
localStorage.setItem("notes",JSON.stringify(notes));
}

function displayNotes(filter=""){

notesContainer.innerHTML="";

notes
.filter(note=>{

const data=(note.title+
note.content+
note.tags.join(" ")).toLowerCase();

return data.includes(filter.toLowerCase());

})

.forEach((note,index)=>{

const div=document.createElement("div");
div.className="note";

div.innerHTML=`
<h3>${note.title}</h3>

<p>${note.content}</p>

<div class="tags">
${note.tags.map(tag=>`<span class="tag">${tag}</span>`).join("")}
</div>

<button class="delete" onclick="deleteNote(${index})">
Delete
</button>
`;

notesContainer.appendChild(div);

});

}

function deleteNote(index){

notes.splice(index,1);

saveNotes();

displayNotes(search.value);

}

addBtn.addEventListener("click",()=>{

if(title.value===""||content.value===""){
alert("Please fill Title and Note");
return;
}

const note={

title:title.value,

content:content.value,

tags:tags.value
.split(",")
.map(tag=>tag.trim())
.filter(tag=>tag!=="")

};

notes.unshift(note);

saveNotes();

displayNotes();

title.value="";
content.value="";
tags.value="";

});

search.addEventListener("input",()=>{

displayNotes(search.value);

});

displayNotes();